# Bass RPG — システム設計書 v2
*Claude Code 引き継ぎ用。既存コード（Hooking v1 / Exploration v2 / LakeDepthField）前提。*

---

## 0. 実装優先順位

```
Phase 1: ストラクチャー当たり判定基盤
Phase 2: 根がかりシステム
Phase 3: ライン干渉システム
Phase 4: ファイト中の魚行動（ストラクチャー逃げ込み）
Phase 5: インベントリ・ショップ
Phase 6: NPC・拠点
```

---

## 1. ゲームループ全体

```
[家（拠点）]
  └─ タックルボックスにルアーを詰める（出発前。出発後変更不可）
        ↓
[フィールド（オーバーワールド）]
  ├─ スポット移動
  ├─ ショップNPC（フィールド内に1箇所）
  │    └─ ポイントでルアー・タックル購入 + ヒント情報
  └─ 釣りスポット入場
        ↓
[釣りビュー]
  └─ キャスト → アクション → ヒット or 根がかり → 回収
        ↓
[釣果]
  └─ サイズ・レアリティ → ポイント加算
```

---

## 2. ストラクチャー当たり判定

### 2-1. UnderwaterCell への追加フィールド

```python
# underwater_map.py の UnderwaterCell に追加
@dataclass
class UnderwaterCell:
    terrain:    int   = TERRAIN_FLAT
    depth:      float = 1.5
    # 以下を追加
    blocking:   bool  = False  # キャスト着水をブロックするか
    snag_weight:float = 0.0    # 根がかり確率の重み（0.0〜1.0）
    weak_dir:   int   = -1     # 外れやすい方向（DIR_UP/DOWN/LEFT/RIGHT / -1=なし）
```

### 2-2. ストラクチャー別パラメータ

| ストラクチャー | blocking | snag_weight | weak_dir |
|---|---|---|---|
| 岩 (ROCK) | True | 0.85 | -1 |
| 倒木 (COVER) | False | 0.65 | 末端方向 |
| 切り株 (STUMP) | False | 0.75 | -1 |
| ウィード (WEED) | False | 0.25 | どの方向も同じ |
| 杭 (PILING) | True | 0.70 | -1 |

### 2-3. ルアー別根がかり耐性

```python
# constants.py に追加
SNAG_RESIST = {
    LURE_WORM:        0.20,
    LURE_JIG:         0.35,
    LURE_CRANKBAIT:   0.70,
    LURE_SPINNERBAIT: 0.75,
    LURE_TOPWATER:    0.95,
}
```

### 2-4. キャストカーソル表示

```python
# fishing_view.py のカーソル描画部分に追加
def _cursor_color(self, cx, cy):
    cell = self.uw_map.cells[cy][cx]
    if cell.blocking:
        return CURSOR_BLINK_RED    # 点滅（着水リスクあり）
    if cell.snag_weight > 0.5:
        return CURSOR_BLINK_ORANGE # 点滅（根がかりリスクあり）
    return CURSOR_NORMAL
```

---

## 3. 根がかりシステム

### 3-1. FS_SNAG ステート

```python
# fight_system.py に追加するステート
FS_SNAG = "snag"

# snag 発生判定（ルアー移動のたびに呼ぶ）
def check_snag(lure_cell, lure_type) -> bool:
    w = lure_cell.snag_weight
    r = SNAG_RESIST.get(lure_type, 0.5)
    return random.random() < w * (1.0 - r)
```

### 3-2. 根がかり解除フロー

```python
class SnagState:
    attempts:   int   = 0       # ロッド操作回数
    snag_cell:  tuple = None    # 根がかったセル座標

def resolve_snag(state: SnagState, rod_dir: int, lure_cell) -> str:
    """
    Returns: "free" | "break" | "still_snagged"
    """
    state.attempts += 1

    base_free  = 0.35 - lure_cell.snag_weight * 0.2
    break_risk = 0.05 + state.attempts * 0.04

    # 正しい方向ボーナス
    if rod_dir == lure_cell.weak_dir:
        base_free += 0.20

    r = random.random()
    if r < break_risk:
        return "break"
    if r < break_risk + base_free:
        return "free"
    return "still_snagged"
```

### 3-3. ラインブレイク処理

```python
def on_line_break(player, spot):
    # ① ルアー消失
    player.inventory.remove_lure(player.current_lure, count=1)

    # ② 周辺魚の強警戒
    propagate_alert(spot, origin=player.lure_pos,
                    radius=10, level=ALERT_HIGH)

    # ③ ルアー残数ゼロなら強制帰還
    if player.inventory.total_lures() == 0:
        return EVENT_FORCE_RETURN
```

---

## 4. ライン干渉システム（新規）

キャスト位置とルアー位置を結ぶ直線上にストラクチャーがある場合にライン干渉が発生。

### 4-1. 経路チェック

```python
def get_line_path(start: tuple, end: tuple) -> list[tuple]:
    """
    Bresenham でキャスト位置〜ルアー位置のセル列を返す。
    start/end は UW グリッド座標 (cx, cy)。
    """
    # ... Bresenham 実装 ...
    return cells_on_line

def check_line_interference(path: list, uw_map) -> tuple | None:
    """
    ライン経路上に snag_weight > 0 のセルがあれば座標を返す。
    なければ None。
    """
    for cx, cy in path[1:-1]:  # 両端除く
        cell = uw_map.cells[cy][cx]
        if cell.snag_weight > 0.3:
            return (cx, cy)
    return None
```

### 4-2. ロッド操作でのライン浮かせ

```python
# 巻き上げ中に上方向ロッド入力でラインを一時的に浮かせる
# → 経路チェックを1セル分スキップできる

LINE_LIFT_DURATION = 60  # フレーム数

def apply_rod_lift(fishing_state):
    if rod_input == DIR_UP:
        fishing_state.line_lift_frames = LINE_LIFT_DURATION
```

---

## 5. ファイト中の魚行動（ストラクチャー逃げ込み）

### 5-1. 魚の逃げ行動

```python
# fish.py の FightingFish クラスに追加

def update_escape_behavior(self, uw_map):
    """
    サイズが大きいほどストラクチャーへ逃げようとする。
    """
    escape_weight = self.length_cm / 60.0  # 60cm で最大

    # 周辺セルのストラクチャーを探す
    nearby_cover = self._find_nearby_cover(uw_map, radius=4)

    if nearby_cover and random.random() < escape_weight * 0.3:
        self.target_cell = nearby_cover  # ストラクチャーへ突っ込む
        self.state = FISH_RUSHING_COVER
```

### 5-2. ロッド入力で魚を誘導

```python
def apply_rod_guidance(fish, rod_dir: int) -> float:
    """
    ロッドを魚の逃げ方向と逆に入力すると抵抗。
    同方向に入力すると魚が寄ってくる。
    Returns: tension_modifier
    """
    fish_dir = fish.get_move_direction()

    if rod_dir == opposite(fish_dir):
        # 抵抗: テンション上昇、ストラクチャー突進を阻止できる
        fish.cover_rush_blocked = True
        return +0.15  # テンション少し上がる

    if rod_dir == fish_dir:
        # 誘導: 魚が寄ってくる、テンション下がる
        fish.pull_player_direction()
        return -0.10

    return 0.0
```

### 5-3. ストラクチャー突進時の処理

```python
def on_fish_reach_cover(fish, player):
    # テンション急上昇
    player.fight_state.tension += 0.35

    # ロッドで引き離せていない場合はラインブレイクリスク大
    if not fish.cover_rush_blocked:
        player.fight_state.break_risk += 0.40
```

---

## 6. 魚の警戒伝播

```python
ALERT_LOW  = "low"   # 根がかり外し成功時
ALERT_HIGH = "high"  # ラインブレイク時

ALERT_RADIUS = {
    ALERT_LOW:  5,   # セル
    ALERT_HIGH: 10,
}
ALERT_BITE_PENALTY = {
    ALERT_LOW:  -0.60,  # バイト確率 -60%
    ALERT_HIGH: -1.00,  # バイトなし（ゾーン離脱）
}
ALERT_DURATION = {
    ALERT_LOW:  300,  # フレーム
    ALERT_HIGH: 900,
}

def propagate_alert(spot, origin, radius, level):
    for fish in spot.fish_list:
        dist = grid_distance(fish.cell, origin)
        if dist <= radius:
            fish.alert_level = level
            fish.alert_timer = ALERT_DURATION[level]
```

---

## 7. インベントリ・タックルシステム

### 7-1. データ構造

```python
# player.py に追加
@dataclass
class TackleBox:
    capacity:   int  = 6        # スロット数（アップグレードで最大12）
    slots: list[dict] = field(default_factory=list)
    # slot: {"lure_id": str, "count": int}

@dataclass
class PlayerInventory:
    tackle_box: TackleBox = field(default_factory=TackleBox)
    points:     int = 0

    def total_lures(self) -> int:
        return sum(s["count"] for s in self.tackle_box.slots)

    def remove_lure(self, lure_id: str, count: int = 1):
        for slot in self.tackle_box.slots:
            if slot["lure_id"] == lure_id:
                slot["count"] -= count
                if slot["count"] <= 0:
                    self.tackle_box.slots.remove(slot)
                return

@dataclass
class PlayerTackle:
    rod_grade:   int = 0  # 0=安竿 1=中竿 2=高竿
    reel_grade:  int = 0  # 0=普通 1=良い 2=最高
    box_grade:   int = 0  # 0=6スロット 1=9スロット 2=12スロット
```

### 7-2. タックル効果

```python
# constants.py に追加

# ロッド: テンション上昇速度を抑制
ROD_TENSION_MULT = {0: 1.0, 1: 0.80, 2: 0.60}

# リール: 魚の寄せ速度
REEL_RETRIEVE_SPEED = {0: 1.0, 1: 1.3, 2: 1.6}

# ドラグ: ラインブレイクしにくくなる
REEL_BREAK_RESIST = {0: 0.0, 1: 0.15, 2: 0.30}

# タックルボックス容量
BOX_CAPACITY = {0: 6, 1: 9, 2: 12}
```

---

## 8. ショップ・NPC

### 8-1. 商品テーブル

```python
SHOP_ITEMS = [
    # 消耗品
    {"id": "worm_basic",    "type": "lure",   "cost": 10,  "stack": 5},
    {"id": "crank_basic",   "type": "lure",   "cost": 25,  "stack": 3},
    {"id": "spinnerbait",   "type": "lure",   "cost": 30,  "stack": 3},
    {"id": "topwater",      "type": "lure",   "cost": 40,  "stack": 3},
    # 永続強化
    {"id": "rod_mid",       "type": "tackle", "cost": 200, "grade": 1},
    {"id": "rod_high",      "type": "tackle", "cost": 500, "grade": 2},
    {"id": "reel_mid",      "type": "tackle", "cost": 250, "grade": 1},
    {"id": "reel_high",     "type": "tackle", "cost": 600, "grade": 2},
    {"id": "box_mid",       "type": "tackle", "cost": 150, "grade": 1},
    {"id": "box_high",      "type": "tackle", "cost": 400, "grade": 2},
]
```

### 8-2. NPCヒントのカテゴリ

```python
NPC_HINTS = {
    "weather": [
        "曇りの日はトップウォーターに出やすいぞ",
        "風が強い日はシャローに魚が寄る",
    ],
    "spot": [
        "北のワンドは朝マズメが熱い",
        "ダムサイト際は水深があるからジグがいい",
    ],
    "season": [
        "産卵前のこの時期はシャローを狙え",
    ],
    "secret": [  # 高好感度で解禁
        "あの倒木の奥に大きいのが潜んでる…",
    ],
}
```

---

## 9. ポイント計算

```python
def calc_points(fish_length_cm: float, is_rare: bool = False) -> int:
    # ベース: サイズ比例
    base = int(fish_length_cm * 0.5)  # 30cm=15pt, 60cm=30pt

    # サイズボーナス
    if fish_length_cm >= 50:
        base = int(base * 2.0)   # 50UPで2倍
    if fish_length_cm >= 60:
        base = int(base * 3.0)   # 60UPで3倍（ランカー）

    # レアリティ補正
    if is_rare:
        base = int(base * 1.5)

    return base
```

---

## 10. 新規ステート一覧（fight_system.py に追加）

| ステート | 説明 |
|---|---|
| `FS_SNAG` | 根がかり中（ルアー） |
| `FS_LINE_SNAG` | ライン干渉による根がかり |
| `FS_LINE_BREAK` | ラインブレイク発生 |
| `FISH_RUSHING_COVER` | 魚がストラクチャーへ突進中 |

---

## 11. 既存コードへの影響範囲

| ファイル | 変更内容 |
|---|---|
| `constants.py` | SNAG_RESIST / ROD_TENSION_MULT / REEL_* / BOX_CAPACITY 追加 |
| `underwater_map.py` | UnderwaterCell に blocking / snag_weight / weak_dir 追加 |
| `fight_system.py` | FS_SNAG / FS_LINE_SNAG / FS_LINE_BREAK ステート追加 |
| `fish.py` | FISH_RUSHING_COVER 行動追加 |
| `fishing_view.py` | カーソル色 / ライン経路チェック / ロッド入力拡張 |
| `player.py` | TackleBox / PlayerInventory / PlayerTackle 追加 |
| `game.py` | ショップ遷移 / 拠点タックル詰め画面 |

