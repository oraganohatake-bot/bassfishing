"""On-screen touch controls for mobile (pygbag) play.

The game is keyboard/mouse driven. Rather than rewrite every input site, this
overlay maps touches on virtual buttons to keyboard/mouse input:

* A directional pad drives the arrow keys. ``pygame.key.get_pressed()`` is
  wrapped so continuous-input code (player movement, cast cursor, rod control)
  sees the virtual keys held. KEYDOWN/KEYUP are also posted so discrete
  handlers fire (e.g. hook-set on ↓ during a bite).
* Action buttons post a single KEYDOWN/KEYUP for a mapped key.
* A REEL button holds the left mouse button down on the water — both the
  event-based retrieve reel and the ``mouse.get_pressed()``-based fight reel
  see it.

**Multi-touch:** real SDL ``FINGER*`` events are handled so several buttons can
be held at once (e.g. REEL while steering the rod with the d-pad during a
fight). Each finger is tracked independently. Desktop falls back to single
mouse-pointer handling so the overlay is still usable/testable with a mouse.
"""

from __future__ import annotations
from typing import Optional, Tuple

import pygame

# Synthetic pointer position for water taps driven by the reel button: open
# water, clear of every on-screen button so the re-dispatched event reaches the
# cast/reel code rather than bouncing off the overlay again.
_REEL_POS = (640, 300)


class _Button:
    def __init__(self, rect, label, key, modes=None):
        self.rect = pygame.Rect(rect)
        self.label = label        # str, or dict keyed by mode
        self.key = key            # int keycode, dict keyed by mode, or None
        self.modes = modes        # None = every mode, else a set of mode names

    def visible(self, mode: str) -> bool:
        return self.modes is None or mode in self.modes

    def key_for(self, mode: str) -> int:
        return self.key[mode] if isinstance(self.key, dict) else self.key

    def label_for(self, mode: str) -> str:
        return self.label[mode] if isinstance(self.label, dict) else self.label


class TouchControls:
    def __init__(self, screen_w: int, screen_h: int):
        self.screen_w, self.screen_h = screen_w, screen_h
        self.mode = "explore"            # set by the game each frame
        self.reel_enabled = False        # set by the game (retrieve / fight)

        self._held: set = set()          # arrow keycodes held via the d-pad
        self._action_keys: set = set()   # action keycodes currently held
        self._reel_holders: set = set()  # finger ids (or "mouse") holding REEL
        self._pressed_btns: set = set()  # action buttons pressed (for drawing)
        self._fingers: dict = {}         # finger_id -> target tuple
        self._mouse_target = None        # target tuple for the desktop mouse
        self._touch_active = False       # latched once any finger is seen

        self.font = pygame.font.Font(None, 28)

        s = 82
        # D-pad (plus layout) bottom-left.
        self.dpad = [
            _Button((87, 421, s, s), "up",    pygame.K_UP),
            _Button((87, 587, s, s), "down",  pygame.K_DOWN),
            _Button((4, 504, s, s),  "left",  pygame.K_LEFT),
            _Button((170, 504, s, s), "right", pygame.K_RIGHT),
        ]
        # Key-mapped action buttons. "ACT" is context sensitive.
        self.actions = [
            _Button((1018, 566, 96, 96),
                    {"explore": "ACT", "fishing": "HOOK"},
                    {"explore": pygame.K_e, "fishing": pygame.K_SPACE}),
            _Button((1158, 24, 84, 84), "BACK", pygame.K_ESCAPE),
            _Button((1042, 360, 84, 84), "KEEP", pygame.K_k, modes={"fishing"}),
            _Button((1148, 360, 84, 84), "REL",  pygame.K_r, modes={"fishing"}),
        ]
        # Reel button (fishing only): holds the mouse button on the water.
        self.reel = _Button((1146, 566, 110, 110), "REEL", None,
                            modes={"fishing"})

    @property
    def _reel_held(self) -> bool:
        return bool(self._reel_holders)

    # ── input-state patches ───────────────────────────────────────────────
    def install_key_patch(self) -> None:
        """Wrap ``pygame.key.get_pressed()`` and ``pygame.mouse.get_pressed()``
        so the d-pad reports held arrow keys and REEL reports a held left mouse
        button (used by the fight-reel logic)."""
        real_keys = pygame.key.get_pressed
        held = self._held

        class _MergedKeys:
            def __init__(self, base):
                self._base = base

            def __getitem__(self, k):
                return bool(self._base[k]) or (k in held)

            def __len__(self):
                return len(self._base)

        pygame.key.get_pressed = lambda: _MergedKeys(real_keys())

        real_mouse = pygame.mouse.get_pressed
        tc = self

        def merged_mouse(*args, **kwargs):
            base = list(real_mouse(*args, **kwargs))
            if tc._reel_held and base:
                base[0] = True
            return tuple(base)

        pygame.mouse.get_pressed = merged_mouse

    # ── hit testing ────────────────────────────────────────────────────────
    def _resolve(self, pos) -> Tuple[str, Optional[_Button]]:
        if (self.mode == "fishing" and self.reel_enabled
                and self.reel.rect.collidepoint(pos)):
            return "reel", self.reel
        for b in self.dpad:
            if b.rect.collidepoint(pos):
                return "dpad", b
        for b in self.actions:
            if b.visible(self.mode) and b.rect.collidepoint(pos):
                return "action", b
        return "water", None

    @staticmethod
    def _post(kind, **kw):
        pygame.event.post(pygame.event.Event(kind, **kw))

    def _press(self, target, fid) -> None:
        kind = target[0]
        if kind == "dpad":
            self._held.add(target[1])
            self._post(pygame.KEYDOWN, key=target[1], mod=0, unicode="")
        elif kind == "action":
            self._action_keys.add(target[1])
            self._pressed_btns.add(target[2])
            self._post(pygame.KEYDOWN, key=target[1], mod=0, unicode="")
        elif kind == "reel":
            first = not self._reel_holders
            self._reel_holders.add(fid)
            if first:
                self._post(pygame.MOUSEBUTTONDOWN, button=1, pos=_REEL_POS,
                           synthetic=True)
        elif kind == "water":
            self._post(pygame.MOUSEBUTTONDOWN, button=1, pos=target[1],
                       synthetic=True)

    def _release(self, target, fid) -> None:
        kind = target[0]
        if kind == "dpad":
            self._held.discard(target[1])
            self._post(pygame.KEYUP, key=target[1], mod=0)
        elif kind == "action":
            self._action_keys.discard(target[1])
            self._pressed_btns.discard(target[2])
            self._post(pygame.KEYUP, key=target[1], mod=0)
        elif kind == "reel":
            self._reel_holders.discard(fid)
            if not self._reel_holders:
                self._post(pygame.MOUSEBUTTONUP, button=1, pos=_REEL_POS,
                           synthetic=True)
        elif kind == "water":
            self._post(pygame.MOUSEBUTTONUP, button=1, pos=target[1],
                       synthetic=True)

    def _make_target(self, pos):
        kind, b = self._resolve(pos)
        if kind == "dpad":
            return ("dpad", b.key)
        if kind == "action":
            return ("action", b.key_for(self.mode), b)
        if kind == "reel":
            return ("reel",)
        return ("water", pos)

    # ── event entry point ────────────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        """Return True if the event was consumed."""
        t = event.type

        # Multi-touch path (phones).
        if t in (pygame.FINGERDOWN, pygame.FINGERUP, pygame.FINGERMOTION):
            self._touch_active = True
            if t == pygame.FINGERDOWN:
                pos = (event.x * self.screen_w, event.y * self.screen_h)
                target = self._make_target(pos)
                self._fingers[event.finger_id] = target
                self._press(target, event.finger_id)
            elif t == pygame.FINGERUP:
                target = self._fingers.pop(event.finger_id, None)
                if target is not None:
                    self._release(target, event.finger_id)
            return True

        # Emulated mouse from a touch is a duplicate of a FINGER event we have
        # already handled — drop it (but never drop our own synthetic events).
        if t in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            if getattr(event, "synthetic", False):
                return False
            if self._touch_active:
                return True
            return self._handle_mouse(event)

        return False

    def _handle_mouse(self, event) -> bool:
        """Single-pointer fallback for desktop (mouse)."""
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            target = self._make_target(event.pos)
            if target[0] == "water":
                return False  # let the game handle the real mouse (cast/reel)
            self._mouse_target = target
            self._press(target, "mouse")
            return True
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self._mouse_target is None:
                return False
            self._release(self._mouse_target, "mouse")
            self._mouse_target = None
            return True
        return False

    # ── drawing ──────────────────────────────────────────────────────────
    def _draw_btn(self, surf, rect, pressed, enabled=True):
        if not enabled:
            fill, border = (255, 255, 255, 18), (255, 255, 255, 60)
        elif pressed:
            fill, border = (255, 255, 255, 95), (255, 255, 255, 150)
        else:
            fill, border = (255, 255, 255, 40), (255, 255, 255, 150)
        pygame.draw.rect(surf, fill, rect, border_radius=14)
        pygame.draw.rect(surf, border, rect, width=2, border_radius=14)

    def _draw_dir_icon(self, surf, b: _Button):
        r = b.rect
        cx, cy = r.centerx, r.centery
        d = 16
        tri = {
            "up":    [(cx, cy - d), (cx - d, cy + d), (cx + d, cy + d)],
            "down":  [(cx, cy + d), (cx - d, cy - d), (cx + d, cy - d)],
            "left":  [(cx - d, cy), (cx + d, cy - d), (cx + d, cy + d)],
            "right": [(cx + d, cy), (cx - d, cy - d), (cx - d, cy + d)],
        }[b.label]
        pygame.draw.polygon(surf, (255, 255, 255, 210), tri)

    def _draw_text(self, surf, rect, text):
        img = self.font.render(text, True, (255, 255, 255))
        img.set_alpha(220)
        surf.blit(img, img.get_rect(center=rect.center))

    def draw(self, screen) -> None:
        overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        for b in self.dpad:
            self._draw_btn(overlay, b.rect, b.key in self._held)
            self._draw_dir_icon(overlay, b)
        for b in self.actions:
            if not b.visible(self.mode):
                continue
            self._draw_btn(overlay, b.rect, b in self._pressed_btns)
            self._draw_text(overlay, b.rect, b.label_for(self.mode))
        if self.reel.visible(self.mode):
            self._draw_btn(overlay, self.reel.rect, self._reel_held,
                           enabled=self.reel_enabled)
            self._draw_text(overlay, self.reel.rect, "REEL")
        screen.blit(overlay, (0, 0))
